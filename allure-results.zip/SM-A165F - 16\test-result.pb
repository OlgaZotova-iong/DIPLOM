

RF8Y409YN3Lprimary�
~
AuthTestru.edu.qamid.uiTests(testLogoutAndReLoginWithoutRestart_TC0082��������:�����Ӹ�B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.AuthTest-testLogoutAndReLoginWithoutRestart_TC008.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
m
AuthTestru.edu.qamid.uiTeststestPositiveLogin_TC0012�����譔:������ÆB
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.AuthTest-testPositiveLogin_TC001.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�$
}
AuthTestru.edu.qamid.uiTests'testNegativeLoginWrongCredentials_TC0032��������:ڜ���ܩ�B
RF8Y409YN3Lprimary�
�androidx.test.espresso.NoMatchingRootException: Matcher 'is a Toast' did not match any of the following roots: [Root{application-window-token=android.view.ViewRootImpl$W@e1b9f5f, window-token=android.view.ViewRootImpl$W@e1b9f5f, has-window-focus=true, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030318
fl=81810100
pfl=10008840
bhv=1
fitSides=0
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true naviIconColor=0}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2340, has-focus=false, has-focusable=true, has-window-focus=true, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030318
fl=81810100
pfl=10008840
bhv=1
fitSides=0
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true naviIconColor=0}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=2}}]
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:2852)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:34)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:26)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:158)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:120)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:385)
at androidx.test.espresso.ViewInteraction.check(ViewInteraction.java:366)
at ru.edu.qamid.pageObjects.AuthPage.checkWrongCredentialsErrorMessage(AuthPage.java:55)
at ru.edu.qamid.uiTests.AuthTest.testNegativeLoginWrongCredentials_TC003(AuthTest.java:75)
.androidx.test.espresso.NoMatchingRootException�androidx.test.espresso.NoMatchingRootException: Matcher 'is a Toast' did not match any of the following roots: [Root{application-window-token=android.view.ViewRootImpl$W@e1b9f5f, window-token=android.view.ViewRootImpl$W@e1b9f5f, has-window-focus=true, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030318
fl=81810100
pfl=10008840
bhv=1
fitSides=0
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true naviIconColor=0}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2340, has-focus=false, has-focusable=true, has-window-focus=true, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030318
fl=81810100
pfl=10008840
bhv=1
fitSides=0
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true naviIconColor=0}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=2}}]
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:2852)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:34)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:26)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:158)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:120)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:385)
at androidx.test.espresso.ViewInteraction.check(ViewInteraction.java:366)
at ru.edu.qamid.pageObjects.AuthPage.checkWrongCredentialsErrorMessage(AuthPage.java:55)
at ru.edu.qamid.uiTests.AuthTest.testNegativeLoginWrongCredentials_TC003(AuthTest.java:75)
"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.AuthTest-testNegativeLoginWrongCredentials_TC003.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
f
AuthTestru.edu.qamid.uiTeststestLogout_TC0072ڜ������:������B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.AuthTest-testLogout_TC007.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�$
w
AuthTestru.edu.qamid.uiTests"testNegativeLoginEmptyFields_TC0042������:ŝ�����oB
RF8Y409YN3Lprimary�
�androidx.test.espresso.NoMatchingRootException: Matcher 'is a Toast' did not match any of the following roots: [Root{application-window-token=android.view.ViewRootImpl$W@fc5ab75, window-token=android.view.ViewRootImpl$W@fc5ab75, has-window-focus=true, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030318
fl=81810100
pfl=10008840
bhv=1
fitSides=0
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true naviIconColor=0}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2340, has-focus=false, has-focusable=true, has-window-focus=true, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030318
fl=81810100
pfl=10008840
bhv=1
fitSides=0
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true naviIconColor=0}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=2}}]
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:2852)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:34)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:26)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:158)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:120)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:385)
at androidx.test.espresso.ViewInteraction.check(ViewInteraction.java:366)
at ru.edu.qamid.pageObjects.AuthPage.checkEmptyFieldsErrorMessage(AuthPage.java:62)
at ru.edu.qamid.uiTests.AuthTest.testNegativeLoginEmptyFields_TC004(AuthTest.java:90)
.androidx.test.espresso.NoMatchingRootException�androidx.test.espresso.NoMatchingRootException: Matcher 'is a Toast' did not match any of the following roots: [Root{application-window-token=android.view.ViewRootImpl$W@fc5ab75, window-token=android.view.ViewRootImpl$W@fc5ab75, has-window-focus=true, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030318
fl=81810100
pfl=10008840
bhv=1
fitSides=0
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true naviIconColor=0}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2340, has-focus=false, has-focusable=true, has-window-focus=true, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030318
fl=81810100
pfl=10008840
bhv=1
fitSides=0
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true naviIconColor=0}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=2}}]
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:2852)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:34)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:26)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:158)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:120)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:385)
at androidx.test.espresso.ViewInteraction.check(ViewInteraction.java:366)
at ru.edu.qamid.pageObjects.AuthPage.checkEmptyFieldsErrorMessage(AuthPage.java:62)
at ru.edu.qamid.uiTests.AuthTest.testNegativeLoginEmptyFields_TC004(AuthTest.java:90)
"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.AuthTest-testNegativeLoginEmptyFields_TC004.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
�
NewsManagementTestru.edu.qamid.uiTests"shouldNotCreateNewsWithoutCategory2ŝ������:ݝ������B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsManagementTest-shouldNotCreateNewsWithoutCategory.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
~
NewsManagementTestru.edu.qamid.uiTestsshouldNotCreateNewsWithoutTitle2ݝ������:䝐����B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsManagementTest-shouldNotCreateNewsWithoutTitle.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�

NewsManagementTestru.edu.qamid.uiTests!shouldHandleMultiplePullToRefresh2䝐����2:����B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsManagementTest-shouldHandleMultiplePullToRefresh.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
�
NewsManagementTestru.edu.qamid.uiTests!shouldCancelNewsCreationAndReturn2����7:������B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsManagementTest-shouldCancelNewsCreationAndReturn.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
�
NewsManagementTestru.edu.qamid.uiTests%shouldHandleDoubleClickOnDeleteButton2�����ۛ�:�����焅B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsManagementTest-shouldHandleDoubleClickOnDeleteButton.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
�
NewsManagementTestru.edu.qamid.uiTests+shouldNotSaveNewsWithEmptyDescriptionOnEdit2������ז:�������`B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsManagementTest-shouldNotSaveNewsWithEmptyDescriptionOnEdit.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
|
NewsManagementTestru.edu.qamid.uiTestsshouldCreateNewsWithValidData2�������z:�������B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsManagementTest-shouldCreateNewsWithValidData.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
r
NewsManagementTestru.edu.qamid.uiTestsshouldEditNewsTitle2�������:��������B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsManagementTest-shouldEditNewsTitle.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
p
NewsManagementTestru.edu.qamid.uiTestsshouldDeleteNews2��������:��������B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsManagementTest-shouldDeleteNews.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
�
NewsManagementTestru.edu.qamid.uiTests%shouldNotCreateNewsWithoutDescription2��������:������فB
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsManagementTest-shouldNotCreateNewsWithoutDescription.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
�
NewsManagementTestru.edu.qamid.uiTests#shouldHandleDoubleClickOnSaveButton2��������:��������B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsManagementTest-shouldHandleDoubleClickOnSaveButton.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
t
NewsManagementTestru.edu.qamid.uiTestsshouldRefreshNewsList2��������:�����ܮB
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsManagementTest-shouldRefreshNewsList.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
n
NewsTestru.edu.qamid.uiTeststestNavigateToQuotes_TC0452������4:�������B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsTest-testNavigateToQuotes_TC045.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
m
NewsTestru.edu.qamid.uiTeststestNavigateToNews_TC0132�������:��������B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsTest-testNavigateToNews_TC013.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
t
NewsTestru.edu.qamid.uiTeststestMultiplePullToRefresh_TC0392��������:�����B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsTest-testMultiplePullToRefresh_TC039.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
x
NewsTestru.edu.qamid.uiTests#testExpandAndCollapseNewsList_TC0102�����:Ǟ������B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsTest-testExpandAndCollapseNewsList_TC010.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
s
NewsTestru.edu.qamid.uiTeststestPullToRefreshOnMain_TC0122Ǟ�����:̞������B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsTest-testPullToRefreshOnMain_TC012.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
s
NewsTestru.edu.qamid.uiTeststestNewsListIsDisplayed_TC0092̞�����:ў������B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.NewsTest-testNewsListIsDisplayed_TC009.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
l

QuotesTestru.edu.qamid.uiTeststestExpandQuote_TC0462ў������:מ�����RB
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.QuotesTest-testExpandQuote_TC046.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo�
n

QuotesTestru.edu.qamid.uiTeststestCollapseQuote_TC0472מ�����y:ܞ���ߪ�B
RF8Y409YN3Lprimary"�

logcatandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\logcat-ru.edu.qamid.uiTests.QuotesTest-testCollapseQuote_TC047.txt"�

device-infoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�C:\MyProjects\fmh_android_updated\fmh_android_updated\app\build\outputs\androidTest-results\connected\debug\SM-A165F - 16\testlog\test-results.log 2
text/plain